<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
        
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; <?php echo e(date('Y')); ?> <a href="<?php echo e(route('dashboard')); ?>"><?php echo e(config('app.name')); ?></a>.</strong> All rights
    reserved.
</footer><?php /**PATH C:\xampp\htdocs\JURUSAN\resources\views/layouts/footer.blade.php ENDPATH**/ ?>